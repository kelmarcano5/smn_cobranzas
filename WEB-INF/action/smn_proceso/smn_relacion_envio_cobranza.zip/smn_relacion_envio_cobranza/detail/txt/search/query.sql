select
select
select
select
	smn_cobranzas.smn_relacion_envio_cobranza.*
from
	smn_cobranzas.smn_relacion_envio_cobranza
where
	smn_relacion_envio_cobranza_id = ${fld:id}
