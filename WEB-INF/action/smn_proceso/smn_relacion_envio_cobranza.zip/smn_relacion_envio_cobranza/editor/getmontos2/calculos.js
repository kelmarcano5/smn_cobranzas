document.form1.rec_monto_ml.value='${fld:monto_doc_ml}';
document.form1.rec_monto_ma.value='${fld:monto_doc_ma}';
document.form1.rec_cantidad_documento.value='${fld:cant_doc@######0}';


