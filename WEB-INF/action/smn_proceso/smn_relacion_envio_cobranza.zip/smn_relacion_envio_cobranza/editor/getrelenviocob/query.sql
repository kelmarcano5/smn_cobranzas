SELECT 

smn_cobranzas.smn_relacion_envio_cobranza.smn_relacion_envio_cobranza_id as id

from smn_cobranzas.smn_relacion_envio_cobranza 
