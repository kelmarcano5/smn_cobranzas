select ${seq:nextval@smn_cobranzas.seq_smn_relacion_envio_cobranza} as id
