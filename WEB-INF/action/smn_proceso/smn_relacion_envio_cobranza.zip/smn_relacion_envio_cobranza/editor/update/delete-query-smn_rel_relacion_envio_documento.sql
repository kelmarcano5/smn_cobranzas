	delete from smn_cobranzas.smn_rel_relacion_envio_documento 
		where smn_relacion_envio_cobranza_id = ${fld:id2};