 and
 	smn_cobranzas.smn_relacion_envio_cobranza.smn_cliente_rf=${fld:smn_cliente_rf}