 and
 	smn_cobranzas.smn_relacion_envio_cobranza.rec_fecha_generacion>=${fld:rec_fecha_generacion}