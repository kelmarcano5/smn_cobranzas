 and
 	smn_cobranzas.smn_relacion_envio_cobranza.smn_entidad_rf=${fld:smn_entidad_rf}