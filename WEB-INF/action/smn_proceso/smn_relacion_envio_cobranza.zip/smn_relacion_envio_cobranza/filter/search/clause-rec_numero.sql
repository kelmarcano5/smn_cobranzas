 and
 	smn_cobranzas.smn_relacion_envio_cobranza.rec_numero=${fld:rec_numero}