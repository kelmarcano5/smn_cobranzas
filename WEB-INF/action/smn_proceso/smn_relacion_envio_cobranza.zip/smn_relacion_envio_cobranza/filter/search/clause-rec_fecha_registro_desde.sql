 and
 	smn_cobranzas.smn_relacion_envio_cobranza.rec_fecha_registro>=${fld:rec_fecha_registro_desde}