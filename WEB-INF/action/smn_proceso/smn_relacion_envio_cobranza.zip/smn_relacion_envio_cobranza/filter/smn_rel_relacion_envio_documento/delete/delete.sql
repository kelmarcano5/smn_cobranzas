delete from smn_base.smn_rel_cuestionario_seccion where smn_rel_cuestionario_seccion_id = ${fld:id}
