search();
alertBox('El registro fue generado', 'Continuar', null, null);
