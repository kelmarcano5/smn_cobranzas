delete from smn_cobranzas.smn_relacion_envio_cobranza where smn_relacion_envio_cobranza_id = ${fld:id}
