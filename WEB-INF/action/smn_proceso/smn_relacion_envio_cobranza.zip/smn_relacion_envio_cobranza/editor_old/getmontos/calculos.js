document.form1.rec_monto_ml.value='${fld:monto_doc_ml@###########0.00}';
document.form1.rec_monto_ma.value='${fld:monto_doc_ma@###########0.00}';
document.form1.rec_cantidad_documento.value='${fld:cant_doc@######0}';


